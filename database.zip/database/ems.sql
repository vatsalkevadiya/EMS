-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2019 at 06:16 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2019-06-20 06:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `ven_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `date`
--

CREATE TABLE `date` (
  `id` int(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `date`
--

INSERT INTO `date` (`id`, `date`) VALUES
(1, '0000-00-00 00:00:00'),
(2, '0000-00-00 00:00:00'),
(22, '2019-06-20 18:43:52'),
(223, '2019-06-20 18:43:52');

-- --------------------------------------------------------

--
-- Table structure for table `getquotelist`
--

CREATE TABLE `getquotelist` (
  `ven_id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `no_of_guest` int(50) NOT NULL,
  `no_of_stage` int(50) NOT NULL,
  `no_of_tables` int(50) NOT NULL,
  `no_of_chairs` int(50) NOT NULL,
  `no_of_sofa` int(50) NOT NULL,
  `services` varchar(100) NOT NULL,
  `date_of_event` date NOT NULL,
  `time_of_event` int(11) NOT NULL,
  `event_venue` varchar(100) NOT NULL,
  `budget` int(50) NOT NULL,
  `otherreq` varchar(300) NOT NULL,
  `inout` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getquotelist`
--

INSERT INTO `getquotelist` (`ven_id`, `usr_id`, `no_of_guest`, `no_of_stage`, `no_of_tables`, `no_of_chairs`, `no_of_sofa`, `services`, `date_of_event`, `time_of_event`, `event_venue`, `budget`, `otherreq`, `inout`) VALUES
(12, 21, 12, 23, 12, 21, 12, 'asd', '0000-00-00', 12, 'sdasdasd', 12, 'asd afdasdfad', 'indoor'),
(3, 29, 12, 12, 12, 12, 12, '12', '0000-00-00', 12, 'ddas', 12, 'afadf fasdf ', 'indoor'),
(3, 29, 1200, 3, 10, 50, 10, 'Wedding receptions', '0000-00-00', 12, 'charni road', 12000, 'no', 'indoor'),
(3, 29, 1200, 2, 20, 50, 10, 'Wedding receptions', '0000-00-00', 12, 'charni road', 120000, 'no', 'indoor'),
(3, 29, 1200, 2, 20, 50, 10, 'Wedding receptions', '0000-00-00', 12, 'charni road', 120000, 'no', 'indoor'),
(3, 29, 1200, 2, 20, 50, 10, 'Wedding receptions', '0000-00-00', 12, 'charni road', 120000, 'no', 'indoor'),
(3, 29, 1200, 2, 20, 50, 10, 'Wedding receptions', '0000-00-00', 12, 'charni road', 120000, 'no', 'indoor'),
(3, 29, 12, 12, 12, 12, 12, 'Wedding receptions', '0000-00-00', 12, 'charni road', 123000, 'asddjhkh', 'indoor'),
(3, 29, 12, 12, 12, 12, 12, 'Wedding receptions', '0000-00-00', 12, 'charni road', 123000, 'asddjhkh', 'indoor'),
(3, 29, 1200, 12, 12, 120, 10, 'wedding', '0000-00-00', 12, 'charni road main raod', 1200000, '', 'indoor'),
(7, 29, 1200, 3, 12, 40, 10, 'wedding', '0000-00-00', 12, 'churchgate', 120000, 'i need full venue decoration', 'indoor'),
(3, 29, 12, 4343, 4335, 43435, 5433, '55', '0000-00-00', 12, 'hgh', 121212, 'jhvvvmbmmn    knkjb', 'indoor'),
(3, 29, 12, 32, 32, 323, 42, 'khjfg', '0000-00-00', 6, 'nbvf', 545675, 'n', 'indoor'),
(3, 29, 12, 32, 32, 323, 42, 'khjfg', '0000-00-00', 6, 'nbvf', 545675, 'n', 'indoor'),
(3, 29, 12, 32, 32, 323, 42, 'khjfg', '0000-00-00', 6, 'nbvf', 545675, 'n', 'indoor'),
(3, 29, 26, 747, 44, 45, 575, 'mnghj', '0000-00-00', 1, 'kjhjhj', 875875, 'gkjkhjjh', 'indoor'),
(3, 29, 26, 747, 44, 45, 575, 'mnghj', '0000-00-00', 1, 'kjhjhj', 875875, 'gkjkhjjh', 'indoor'),
(3, 29, 26, 747, 44, 45, 575, 'mnghj', '0000-00-00', 1, 'kjhjhj', 875875, 'gkjkhjjh', 'indoor'),
(3, 29, 12, 12, 12, 12, 12, 'kj', '0000-00-00', 12, 'kjkhjgkj', 121212, '', 'indoor'),
(3, 29, 1212, 221, 12, 2126, 575, 'ggjh', '0000-00-00', 5, 'gg', 85, 'hh', 'indoor'),
(3, 29, 755, 5755, 676, 8786, 55, 'nb', '0000-00-00', 7, '', 86, 'kgkb', 'indoor');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `img_id` int(11) NOT NULL,
  `ven_id` int(11) NOT NULL,
  `img_path` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`img_id`, `ven_id`, `img_path`) VALUES
(6, 3, '1561170061wedding3.jpg'),
(7, 3, '1561170061wedding7.jpg'),
(8, 3, '1561170061wedding5.jpg'),
(9, 3, '1561170061wedding4.jpg'),
(14, 7, '1561180673business2.jpg'),
(15, 7, '1561180673business4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `usr_id` int(11) NOT NULL,
  `usr_name` varchar(50) NOT NULL,
  `usr_email` varchar(50) NOT NULL,
  `usr_pass` varchar(100) NOT NULL,
  `usr_num` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usr_id`, `usr_name`, `usr_email`, `usr_pass`, `usr_num`) VALUES
(29, 'vatsal', 'vatzkk02@gmail.com', 'vatsal', 2147483647),
(30, 'nivant', ' nivant@gmail.com', 'nivant123', 446465453),
(31, 'hasmita', 'hasmita@gmail.com', 'hasmita123', 57686545);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `ven_id` int(20) NOT NULL,
  `ven_name` varchar(100) NOT NULL,
  `ven_email` varchar(100) NOT NULL,
  `ven_pass` varchar(100) NOT NULL,
  `ven_num` int(200) NOT NULL,
  `ven_service` varchar(50) NOT NULL,
  `ven_sub_services` varchar(150) NOT NULL,
  `ven_loc` varchar(50) NOT NULL,
  `ven_desc` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`ven_id`, `ven_name`, `ven_email`, `ven_pass`, `ven_num`, `ven_service`, `ven_sub_services`, `ven_loc`, `ven_desc`) VALUES
(3, 'Bairaipvtltd', 'bairaipvtltd@gmail.com', 'bairai123', 2027469354, 'wedding', 'Wedding receptions', 'Marine Lines', 'Bairai are best recognized as Event and Wedding Planner in the Mumbai. The activities of Bairai have put thrust upon wedding events; for over 8 years Bairai has been in constant service to its esteemed clients and customers. \"Customers satisfaction is our best achievement\" is the motto of Bairai. Bairai is pledged to solemnize various events & programs at its customers choice. The events like Wedding Events and many more are conducted to accomplish at its best of service disposal of Bairai. Down'),
(6, 'alif pvt ltd', 'alif12@gmail.com', 'alif1234', 2012457898, 'Caterers', 'Wedding caterers,Corporate caterers', 'Dadar', 'We provide good catering services all over Mumbai. we provide best of wedding caterers and corporate caterers '),
(7, 'kevadiya pvt ltd', 'kevadiya@gmail.com', 'keva123', 2023568978, 'Caterers', 'Cakes,Make-up and Hair', 'Mumbai Central', 'We provide best of fresh cakes all over Mumbai. Our cakes are all customized according to the event. We have professional makeup artist and hair stylist who have also styled many of the bollywood celebs. Contact us for fresh cakes & best makeup and hair artist.   '),
(8, 'kapoor & sons pvt ltd', 'kapoor@gmail.com', 'kapoor1256', 2025588745, 'Parties', 'Baby shower,dinner parties', 'Byculla', 'We have planned exclusive dinner parties with the variety of food which also include the variation of the food example Sushi,Italian,Mexican with fusion of Desi Tadka. We also Organize small function like Baby Shower. Contact us for best of services.'),
(9, 'khana pvt ltd', 'khana123@gmail.com', 'khana123', 2015639887, 'Wedding', 'Stage Decorators,Lights & Sounds Services', 'Bandra', 'Till now we have organized & managed more than hundred stage events all over Mumbai with the best of sound & light services. Contact us to get more information.'),
(10, 'purohit pvt ltd', 'purohit02@gmail.com', 'purohit123', 2012124578, 'Wedding', 'Mehendi ceremony,Sangeet ceremony,Ring ceremony', 'Goregaon', 'Purohit pvt ltd provide wedding services which include best Mehendi designs(Indian,Arabic etc). We also provide sangeet ceremony,mehendi ceremony &  ring ceremony. Contact us for more information regarding our services.'),
(11, 'patils & co', 'patil2@gmail.com', 'patil123', 2012326545, 'Corporate Events', 'Exhibition,Trade Shows & Product Launch Events.', 'Andheri', 'patil & co are famous all over mumbai for their best of exhibition & trade show services upto the date. We have also provided many of the product launch events for multinational companies. Contact us for booking and information related services.'),
(12, 'hasmita pvtltd', 'hasmita123@gmail.com', '893352b4fdcdca740c5f852c9ee6acb3', 987526, 'Corporate', 'Seminars and Conferences,Networking events,Dealer meets,Corporate outings', 'charni road', ''),
(13, '', '', 'd41d8cd98f00b204e9800998ecf8427e', 2147483647, '', '', '', ''),
(14, '', '', 'd41d8cd98f00b204e9800998ecf8427e', 2147483647, '', '', '', ''),
(15, 'test', 'tes@LIVE.COM', 'cc03e747a6afbbcbf8be7668acfebee5', 2147483647, 'Wedding', 'Wedding Anniversaries,Ring ceremony,Make-up and Hair,Mehandi', 'marine', 'djahsj adlkhshdlfkklsd  df lhalksdhf lkhsdf'),
(16, 'test2', 'test@l.com', 'cc03e747a6afbbcbf8be7668acfebee5', 686454534, 'Party', 'Baby shower,Dj,Pool parties', 'charni road', 'fjahjdf kadfa,mnf akjdf,masf'),
(17, 'test2', 'test@l.com', 'cc03e747a6afbbcbf8be7668acfebee5', 686454534, 'Party', 'Baby shower,Dj,Pool parties', 'charni road', 'fjahjdf kadfa,mnf akjdf,masf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usr_id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`ven_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `usr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `ven_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
