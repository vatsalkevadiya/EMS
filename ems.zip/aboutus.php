<!DOCTYPE HTML>

<html>
	
		<title>About us</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<style>



		</style>
		<link rel="stylesheet" href="mdb.min.css">
	</head>
	<body>
	
	
		<!-- Header -->
			<header id="header">
				<div class="logo"><a href="#">About Us </a></div>
			</header>

		<!-- Main -->
			<section id="main">
				<div class="inner">

				<!-- One -->
					<section class="wrapper style1">

						<div class="image fit flush">
							<img src="images\backcoll.jpg" alt="" />
						</div>
						<header class="special">
							<h2>Who we are & What We Do</h2>
							<p>Our Event Management Services</p>
						</header>
						<div class="content">
							<p>Eventoz is an Online event management website that serves the functionality of an event manager</p>
							<p>Our goal is makes work easy for user’s to find event planners and it allows user’s to propose their quotation so that event organization can approve it, if  it’s appropriate.</p>
						    <p>Our organizer's help you in organizing your events within your budget.We plan your events base on its purpose like festival, ceremony, personal or corporate party or convention.</p>
							<p>Our events organization services include a complete process. That is; budgeting, event dates, selecting and reserving the event venue.</p>
						</div>
					</section>


		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

			<script>
	scrollFunction();
	function scrollFunction() {
	
	    document.getElementById("myBtn").style.display = "block";
	}
	function backtohome(){

	}
</script>
	</body>
</html>