<!DOCTYPE html>
<html lang="en" >
<?php include('connection.php');?>
<head>
  <meta charset="UTF-8">
<?php  
  if(isset($_GET['services'])){
    echo "<title>Search results | ".$_GET['services']."</title>";
  }
  if(isset($_GET['loc'])){
    echo "<title>Search results | ".$_GET['loc']."</title>";
  }
  if(isset($_GET['service'])){
    echo "<title>Search results | ".$_GET['service']."</title>";
  }
?>
 <!--navbar starts here-->
 <link rel="stylesheet" href="css/searchnav.css">
  
  <script src="https://kit.fontawesome.com/634ca7f6c9.js"></script>
  <!--navbar ends here-->

  <!--search page-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
  

<!-- footer CSS Stylesheet -->
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="fstyle.css">
    <!-- footer Used Fonts -->
    <link href="./Event Planning_files/css" rel="stylesheet">
    

    <!--location-->
    <link rel="stylesheet" href="css/fstdropdown.css">
    


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style>
.menu{

  font-size:15px;
}
 
.leftside{

  margin-left:-80px;
  margin-top:50px;
}
.list-group{
  font-size:1.2vw;
}
.leftside h1{
 margin-left:25%;
 font-size:2.5vw;
}

.search-content{
  margin-right:-170px;
  margin-top:40px;
}
.btn a{
color:white;
text-decoration:none;
}
.search-count{
margin-top:30px;
margin-left:20px;
}
</style>


    </head>


<body>
 
<nav class="menu">
      <ul class="menu__list">
        <li class="menu__group logo"><a href="#" class="menu__link">Eve<span>n</span>toz</a></li>
        <li class="menu__group"><a href="index.php" class="menu__link"><i class="fas fa-home"></i> &nbsp;Home</a></li>
        <li class="menu__group"><a href="aboutus.php" class="menu__link"><i class="fas fa-users"></i></i> &nbsp;About us</a></li>
        <li class="menu__group"><a href="contactus.php" class="menu__link"><i class="fas fa-book"></i> &nbsp;Contact us</a></li>
      </ul>
    </nav>
  </div>
</div>
  




  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3 leftside" >

      <h1>Location</h1>



<form action="" method="get">
 <input list="brow" name="loc" onchange="this.form.submit();" style="width:100%;">
<datalist id="brow" >
  <option value="Charni road">
  <option value="Churchgate">
  <option value="Andheri">
  <option value="Dadar">
  <option value="Mumbai Central">
  <option value="Byculla">
  <option value="Goregaon">
  <option value="Marine Lines">
  <option value="Andheri">

</datalist>  
</form>
        <h1 class="my-4">Services</h1>
        <div class="list-group">
          <a href="?services=caterers" class="list-group-item">Caterers</a>
          <a href="?services=Decor" class="list-group-item">Decor &amp; Florists</a>
          <a href="?services=Event Planner" class="list-group-item">Event Planner</a>
          <a href="?services=Make-up and Hair" class="list-group-item">Make-up and Hair</a>
          <a href="?services=Wedding Cards" class="list-group-item">Wedding Cards</a>
          <a href="?services=Mehandi" class="list-group-item">Mehandi</a>
          <a href="?services=Cakes" class="list-group-item">Cakes</a>
          <a href="?services=Photographers and Videographers" class="list-group-item">Photographers &amp; Videographers</a>
          <a href="?services=Entertainment" class="list-group-item">Entertainment</a>
          <a href="?services=Lights & sound" class="list-group-item">Lights & sound</a>
          <a href="?services=Valet parking" class="list-group-item">Valet parking</a>
          <a href="?services=Security" class="list-group-item">Security</a>
          <a href="?services=Gifts" class="list-group-item">Gifts</a>

        </div>

      </div>
      <!-- /.col-lg-3 -->

      <!--search content-->
      
      <div class="col-lg-9 ">
      <div class="row search-count">
      
      <?php 
      $num=0;
      if(isset($_GET['services'])){
        $search_services=$_GET['services'];
        $vendor_query="SELECT * FROM vendors WHERE ven_sub_services LIKE '%$search_services%'";
        $getvendors=mysqli_query($conn,$vendor_query);
        $num=mysqli_num_rows($getvendors);
      }
      ?>
      <?php 
      if(isset($_GET['loc'])){
        $search_services=$_GET['loc'];
        $vendor_query="SELECT * FROM vendors WHERE ven_loc LIKE '%$search_services%'";
        $getvendors=mysqli_query($conn,$vendor_query);
        $num=mysqli_num_rows($getvendors);
      }
      ?>
      <?php 
      if(isset($_GET['service'])){
        $search_services=$_GET['service'];
        $vendor_query="SELECT * FROM vendors WHERE ven_service LIKE '%$search_services%'";
        $getvendors=mysqli_query($conn,$vendor_query);
        $num=mysqli_num_rows($getvendors);
      }
      ?>
      <h1>Results found <?php echo $num ?> </h1>
        </div>
<form action="" method="get">
<div class="row search-content" >

<!--services based search-->
    


      <?php 
      
      	if(isset($_GET['services'])){
          $search_services=$_GET['services'];
					$vendor_query="SELECT * FROM vendors WHERE ven_sub_services LIKE '%$search_services%'";
          $getvendors=mysqli_query($conn,$vendor_query);
          
          while($row = mysqli_fetch_assoc($getvendors)){
            
          $ven_id=$row['ven_id'];
          $ven_name=$row['ven_name'];
          $ven_eamil=$row['ven_email'];
          $ven_num=$row['ven_num'];
          $ven_service=$row['ven_service'];
          $ven_sub_services=$row['ven_sub_services'];
          $ven_loc=$row['ven_loc'];
          $ven_desc=$row['ven_desc'];
    
      ?>

      
<div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 ">
              <a href="#"><img class="card-img-top img-responsive" src="images/corp.png" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <?php echo $ven_name; ?>
                </h4>
                <h5><i class="fas fa-map-marker-alt"></i> <?php echo $ven_loc; ?> </h5>
                <p class="card-text" > <?php echo substr($ven_desc,0,100) ."...";?> </p>
              </div>
              <div class="card-footer d-inline">
                <h5 style="font-size:20px;"> Comments <br> 
                <span style="margin-left:10%;">(3)</span>
                <button class="btn btn-info " style="float:right;padding:10px" type="submit" ><a href="vendors/index.php?v_id=<?php echo $ven_id; ?>" > More details</a></button></h5>
              </div>
            </div>
          </div>

          <?php } } ?>

          <!--location based search-->
          <?php 
      
      if(isset($_GET['loc'])){
        $search_loc=$_GET['loc'];
        $vendor_query="SELECT * FROM vendors WHERE ven_loc LIKE '%$search_loc%'";
        $getvendors=mysqli_query($conn,$vendor_query);
      
        while($row = mysqli_fetch_assoc($getvendors)){
          
        $ven_id=$row['ven_id'];
        $ven_name=$row['ven_name'];
        $ven_eamil=$row['ven_email'];
        $ven_num=$row['ven_num'];
        $ven_service=$row['ven_service'];
        $ven_sub_services=$row['ven_sub_services'];
        $ven_loc=$row['ven_loc'];
        $ven_desc=$row['ven_desc'];
  
    ?>

    
<div class="col-lg-4 col-md-6 mb-4">
          <div class="card h-100 ">
            <a href="#"><img class="card-img-top img-responsive" src="images/corp.png" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <?php echo $ven_name; ?>
              </h4>
              <h5><i class="fas fa-map-marker-alt"></i> <?php echo $ven_loc; ?> </h5>
              <p class="card-text" > <?php echo substr($ven_desc,0,100) ."...";?> </p>
            </div>
            <div class="card-footer d-inline">
              <h5 style="font-size:20px;"> Comments <br> 
              <span style="margin-left:10%;">(3)</span>
              <button class="btn btn-info " style="float:right;padding:10px" type="submit" ><a href="vendors/index.php?v_id=<?php echo $ven_id; ?>" > More details</a></button></h5>
            </div>
          </div>
        </div>

        <?php } } ?>

          <!--service based search-->
          <?php 
      
      if(isset($_GET['service'])){
        $search_service=$_GET['service'];
        $vendor_query="SELECT * FROM vendors WHERE ven_service LIKE '%$search_service%'";
        $getvendors=mysqli_query($conn,$vendor_query);
      
        while($row = mysqli_fetch_assoc($getvendors)){
          
        $ven_id=$row['ven_id'];
        $ven_name=$row['ven_name'];
        $ven_eamil=$row['ven_email'];
        $ven_num=$row['ven_num'];
        $ven_service=$row['ven_service'];
        $ven_sub_services=$row['ven_sub_services'];
        $ven_loc=$row['ven_loc'];
        $ven_desc=$row['ven_desc'];
  
    ?>

    
<div class="col-lg-4 col-md-6 mb-4">
          <div class="card h-100 ">
            <a href="#"><img class="card-img-top img-responsive" src="images/corp.png" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <?php echo $ven_name; ?>
              </h4>
              <h5><i class="fas fa-map-marker-alt"></i> <?php echo $ven_loc; ?> </h5>
              <p class="card-text" > <?php echo substr($ven_desc,0,100) ."...";?> </p>
            </div>
            <div class="card-footer d-inline">
              <h5 style="font-size:20px;"> Comments <br> 
              <span style="margin-left:10%;">(3)</span>
              <button class="btn btn-info " style="float:right;padding:10px" type="submit" ><a href="vendors/index.php?v_id=<?php echo $ven_id; ?>" > More details</a></button></h5>
            </div>
          </div>
        </div>

        <?php } } ?>

        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

          </form>  
    
    <!--dropdown search-->
    <script src="fstdropdown.js"></script>
    
    <!-- search page -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 <script>
 $(document).ready(function(){
$("input").click(function(){
        $(this).next().show();
        $(this).next().hide();
    });

});
 </script>





