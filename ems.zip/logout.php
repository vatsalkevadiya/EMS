<?php
session_start();
ob_start();
$_SESSION['ulogin']=null;
$_SESSION['vlogin']=null;

header("Location: index.php");
?>