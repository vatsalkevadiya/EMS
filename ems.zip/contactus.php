<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php

if(isset($_POST['send'])){
	
	$body=$_POST['body'];
	$name=$_POST['name'];
	$from="From: ".$_POST['email'];
	$subject=$_POST['subject'];
	mail("eventoz2019@gmail.com",$subject,$body,$from);
}
?>
<html lang="zxx">

<head>
	
	<!-- Meta-Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Slide Contact Form Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta-Tags -->
	<!-- Stylesheets -->
	<link href="css/contact.css" rel='stylesheet' type='text/css' />
	<!--// Stylesheets -->
	<!-- online fonts -->
	<link href="//fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<style>
body{

	background:url(images/wed.jpg) no-repeat center;
	background-size:cover;
}
</style>
<title>Eventoz | contact us</title>
</head>

<body>
	
	<section id="hire">
		<div class="content-top-agile">
			<h2>contact us</h2>
		</div>
		<div class="content-bottom">
			<form action="" method="post">
				<div class="field name-box">
					<input type="text" name="name" id="name" placeholder="Your name here" required/>
					<label for="name">Name</label>
				</div>
				<div class="field name-box">
					<input type="text" name="subject" id="name" placeholder="Your subject here" required/>
					<label for="name">Subject</label>
				</div>
				<div class="field email-box">
					<input type="text" name="email" id="email" placeholder="name@email.com" required />
					<label for="email">Email</label>
				</div>
				<div class="field msg-box">
					<textarea id="msg" name="body" placeholder="Your message here.." required></textarea>
					<label for="msg">Inquiry</label>
				</div>

				<input class="button" type="submit" name="send" value="Send" />
			</form>
		</div>
	</section>
	
	<script src="js/jquery-2.2.3.min.js"></script>
	<script src="js/contact.js"></script>
</body>

</html>