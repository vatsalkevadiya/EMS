
<?php
include ('connection.php');

if(isset($_POST['getquote'])){
  $no_of_guest=$_POST['noofguest'];
  $no_of_stage=$_POST['noofstage'];
  $no_of_tables=$_POST['nooftables'];
  $no_of_chair=$_POST['noofchair'];
  $no_of_sofa=$_POST['noofsofa'];
  $services=$_POST['services'];
  $date_of_event=$_POST['dateofevent'];
  $time_of_event=$_POST['timeofevent'];
  $event_venue=$_POST['eventvenue'];
  $budget=$_POST['budget'];
  $otherreq=$_POST['otherreq'];
  $inout=$_POST['inout'];

  $getquotequery="INSERT INTO getquotelist VALUES($no_of_guest,$no_of_stage,$no_of_tables,$no_of_chair,$no_of_sofa,'$services',$date_of_event,$time_of_event,'$event_venue',$budget,'$otherreq','$inout')";

  $result=mysqli_query($conn,$getquotequery);
if(!$result){
die("failed query").mysqli_error();
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="getquote.css">
</head>
<body>
  
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <div class="container">
                <div class="row">
                <div class="col-md-6">
                    <div class="form_main">
                            <h4 class="heading"><strong>Get </strong> Quotation <span></span></h4>
                            <div class="form">
                <form action="" method="POST">
                  <div class="form-group">
                    <label for="guest" class="col-form-label">No of guest:</label>
                    <input name="noofguest" type="number" class="form-control" id="guest">
                  </div>
                  <div class="form-group">
                        <label for="stage" class="col-form-label">No of stage:</label>
                        <input name="noofstage" class="form-control" id="stage">
                      </div>
                    <div class="form-group">
                      <label for="tables" class="col-form-label">No of tables:</label>
                      <input name="nooftables" class="form-control" id="tables">
                    </div>
                    <div class="form-group">
                            <label for="chairs" class="col-form-label">No of chairs:</label>
                            <input name="noofchair" class="form-control" id="chairs">
                          </div>
                    <div class="form-group">
                        <label for="sofa" class="col-form-label">No of sofa:</label>
                        <input name="noofsofa" class="form-control" id="sofa">
                     </div>
                     <div class="form-group">
                          <label for="Services" class="col-form-label">Services:</label>
                          <input name="services" class="form-control" id="Services">
                      </div>
                        <div class="form-group">
                            <label class="col-form-label">Date of event:</label>
                                <input name="dateofevent" id="datepicker" class="form-control" placeholder="Choose">
                            </div>
                        <div class="form-group">
                                <label for="time" class="col-form-label">Time of event:</label>
                                <input name="timeofevent" class="form-control" id="time">
                            </div>
                        <div class="form-group">
                             <label for="venue" class="col-form-label">Event venue:</label>
                             <input name="eventvenue" class="form-control" id="venue">
                        </div>
                       <div class="form-group">
                          <label for="Budget" class="col-form-label">Budget:</label>
                          <input name="budget" class="form-control" id="Budget">
                         </div>
                         <div class="form-group">
                            <label for="req" class="col-form-label">Other requirements:</label>
                             <input name="otherreq" class="form-control" id="req">
                        </div> 
                        <div class="form-group">
                          <label  class="col-form-label">Indoor or Outdoor:</label>
                            <select name="inout" class="btn select">
                                <option value="indoor">Indoor</option>
                                <option value="outdoor">Outdoor</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="getquote" value="Get qoute" class="btn btn-light">
                        </div>
                </form>
              </div>
              </div>
            </div>
        </div>
    </div>
</div>
</div>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
                $(function() {
$( "#datepicker" ).datepicker({
dateFormat : 'mm/dd/yy',
changeMonth : true,
changeYear : true,
yearRange: '-100y:c+nn',
maxDate: ''
});
});

                </script>
</body>
</html>
