 <html><head>
 <!--navbar starts here-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="navstyle.css">
  <script src="https://kit.fontawesome.com/634ca7f6c9.js"></script>
  <!--navbar ends here-->

  <!--cards starts here-->
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <link rel="stylesheet" href="homecards.css">
  <!--cards ends here-->
  <link href="style.css" rel="stylesheet">
  
  <link rel="shortcut icon" href="images/Favicon.ico">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  


<!-- footer CSS Stylesheet -->
<link href="./Event Planning_files/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="./Event Planning_files/styles.css" rel="stylesheet"><!-- font css --> 
    <link href="./Event Planning_files/loader.css" rel="stylesheet"><!-- Loader Box css -->
    <link href="./Event Planning_files/docs.css" rel="stylesheet"><!--  template structure css -->
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="fstyle.css">
     footer Used Fonts 
    <link href="./Event Planning_files/css" rel="stylesheet">



   