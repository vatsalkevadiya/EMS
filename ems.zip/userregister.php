<!DOCTYPE html>
<html lang="en">

<?php
include ('connection.php');
if(isset($_POST['regusr'])){

    $usr_name=$_POST['usr_name'];
    $usr_email=$_POST['usr_email'];
    $usr_pass=$_POST['usr_pass'];
    $usr_num=$_POST['usr_num'];

    $reg_usr="INSERT INTO users(usr_name,usr_email,usr_pass,usr_num) VALUES('$usr_name','$usr_email','$usr_pass','$usr_num')";
    $result=mysqli_query($conn,$reg_usr);}
    ?>




<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<style>
    body{
        background-image: url('corp.png');
        background-size: cover;
        background-repeat: no-repeat;
    }
.note
{
    text-align: center;
    height: 80px;
    background: -webkit-linear-gradient(left, #0072ff, #8811c5);
    color: #fff;
    font-weight: bold;
    line-height: 80px;
}

.form-content
{
    padding: 5%;
    border: 1px solid #ced4da;
    margin-bottom: 2%;
    background: white;
}
.container{
    width: 500px;
    margin-top:10%;

}
.form-control{
    border-radius:1.5rem;
}
.btnSubmit 
{
    border:none;
    border-radius:1.5rem;
    padding: 1%;
    width: 20%;
    cursor: pointer;
    background: #0062cc;
    color: #fff;
    outline: 0;
}
.btnSubmit a{
    text-decoration: none;
    color: white;
} 

.btnSubmit:hover{
    background: white;
    color: #0062cc;
    border: 1.5px solid #0062cc;
}
.btnSubmit a:hover{
    color: #0062cc;
}
</style>
</head>
<body>
        <div class="container register-form " align="center">
                <div class="form">
                    <div class="note">
                        <p>Register</p>
                    </div>
    
                    <div class="form-content" >
                        <div class="row">
                            <div class="col-md-12 ">
                                <form action="" method="POST">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" name="usr_name"/>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email *" name="usr_email"/>
                                </div>
                     
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Password *" name="usr_pass"/>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Phone number *" name="usr_num"/>
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="regusr" class="btnSubmit" >Submit</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
</body>
</html>