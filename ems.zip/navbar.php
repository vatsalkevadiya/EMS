<!DOCTYPE html>
<html lang="en" >
<?php
session_start();


  if(!isset($_SESSION['ulogin'])){
      header ("Location: userlogin.php");
  }

?>
<head>
  <meta charset="UTF-8">
  


 <!--navbar starts here-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/navstyle.css">
  <script src="https://kit.fontawesome.com/634ca7f6c9.js"></script>
  <!--navbar ends here-->

  <!--cards starts here-->
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <link rel="stylesheet" href="css/homecards.css">
  <!--cards ends here-->
  <link href="css/style.css" rel="stylesheet">
  
  



  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  

  
 <!--dropdown search-->
 <link rel="stylesheet" href="css/fstdropdown.css">

<!-- footer CSS Stylesheet -->
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/fstyle.css">
    <!-- footer Used Fonts -->
    <link href="./Event Planning_files/css" rel="stylesheet">



  <style>
    /*slide start */
   * {box-sizing: border-box}
 body {font-family: Verdana, sans-serif; margin:0}
 .mySlides {display: none;}
 .slideshow-container img {
   vertical-align: middle;
   height:500px;
 }
 
 /* Slideshow container */
 .slideshow-container {
   max-width: 90%;
   position: relative;
   margin: auto;
   margin-bottom:50px;
 }
 
 /* Next & previous buttons */
 .prev, .next {
   cursor: pointer;
   position: absolute;
   top: 50%;
   width: auto;
   padding: 16px;
   margin-top: -22px;
   color: white;
   font-weight: bold;
   font-size: 18px;
   transition: 0.6s ease;
   border-radius: 0 3px 3px 0;
   user-select: none;
 }
 
 /* Position the "next button" to the right */
 .next {
   right: 0;
   border-radius: 3px 0 0 3px;
 }
 
 /* On hover, add a black background color with a little bit see-through */
 .prev:hover, .next:hover {
   background-color: rgba(0,0,0,0.8);
 }
 
 
 /* Caption text */
 
 .link{
   background-color:black;
   color:white;
   padding:10px;
   font-family:'Hind', sans-serif;
   width:20vw;
   margin-left:22vw;
   text-decoration:none;
   border: 1px solid #f1f1f1;
 }
 
 .link:hover{
   color:black;
   background-color:white;
 }
 .link:hover a{
   text-decoration :none;
 }
 .slide-text {
   color: white;
   border: 3px solid #f1f1f1;
   background-color: rgb(0,0,0);
   background-color: rgba(0,0,0, 0.4); 
   font-size: 2vw;
   font-family:"Comic Sans MS", cursive, sans-serif;
   padding: 8px 12px;
   position: absolute;
   font-weight:bold;
   bottom: 16px;
   left:10%;
   width: 80%;
   text-align: center;
 }
 
 
 /* Fading animation */
 .fade {
   -webkit-animation-name: fade;
   -webkit-animation-duration: 3.5s;
   animation-name: fade;
   animation-duration: 3.5s;
 }
 
 @-webkit-keyframes fade {
   from {opacity: .2} 
   to {opacity: 1}
 }
 
 @keyframes fade {
   from {opacity: .2} 
   to {opacity: 1}
 }
 
 /* On smaller screens, decrease text size */
 @media only screen and (max-width: 300px) {
   .prev, .next,.slide-text {font-size: 11px}
 }
  /*slide ends */
 </style>

</head>
<body>
    <nav class="menu">
      <ul class="menu__list">
        <li class="menu__group logo"><a href="#" class="menu__link">Eve<span>n</span>toz</a></li>
        <li class="menu__group"><a href="#0" class="menu__link"><i class="fas fa-home"></i> &nbsp;Home</a></li>
        <li class="menu__group"><a href="#services" class="menu__link"><i class="fas fa-info-circle"></i></i> &nbsp;services</a></li>        
        <li class="menu__group"><a href="aboutus.php" class="menu__link"><i class="fas fa-users"></i></i> &nbsp;About us</a></li>
        <li class="menu__group"><a href="contactus.php" class="menu__link"><i class="fas fa-book"></i> &nbsp;Contact us</a></li>
        <li class="menu__group"><div class="btn-group">
  <button type="button" class="btn btn-info dropdown-toggle menu__link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-chevron-down"></i> Profile
  </button>
  <div class="dropdown-menu">
    <?php 
    if(!isset($_SESSION['ulogin'])){
    ?>
    <a class="dropdown-item" href="userlogin.php">Login</a>
    <?php } else { ?>
    <a class="dropdown-item" href="logout.php">Logout</a>
    <?php } ?>
  </div>
  </li>
  
</div>
      </ul>
    </nav>
  </div>
</div>
  

