
        

        <footer id="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6 col-md-3">
                           
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-3 col-md-3 text-center">
                            <div class="footer-link">
                                <h5>Company</h5>
                                <ul>
                                    <li><a href="">About Us</a></li>
                                    <li><a href="">Services</a></li>
                                    <li><a href="vendors/vendorreg">Register as vendor</a></li>
                                    <li><a href="">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6 col-md-3">
                            <div class="footer-contact">
                                <h5>Contact us</h5>
                                <div class="contact-slide">
                                    <p> Complex near Churchgate railway station, Mumbai-400004 </p>
                                </div>
                                <div class="contact-slide">
                                        <h6>Report an issue.</h6>
                                    </div>
                                <div class="contact-slide">

                                    <a href="mailto:eventoz2019@gmail.com">eventoz2019@gmail.com</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-md-3">
                            <div class="contact-form">
                                <h5>Connect with us</h5>
                                <p>We'll keep you informed and updated Sign up for our email newsletters </p>
                                <div class="input-row">
                                    <div class="input-box">
                                        <input type="text text-color" placeholder="First Name">
                                    </div>
                                    <div class="input-box">
                                        <input type="text text-color" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="input-row email">
                                    <div class="input-box">
                                        <input type="text text-color" placeholder="Email Address">
                                    </div>
                                    <div class="submit-box">
                                        <input type="submit" value="Submit">
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </footer>
    </div>
    
    <!--dropdown search-->
    <script src="fstdropdown.js"></script>
    
    <!-- search page -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!--loaction-->
  <script src="fstdropdown.js"></script>

</body>
</html>

