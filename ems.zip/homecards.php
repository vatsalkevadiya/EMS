
 <h1 class="title maintitle" style="color:#34495e;font-size:5vw;" id="services"><hr/>Services</h1>
<div class="cards">
<div class="carousel-wrapper">
   
    
  <div class="carousel" data-flickity>
    
  <div class="carousel-cell" onclick="index.php">
      <h3 class="title">Parties</h3>
      <a href=""><img class="cardimg" src="images/partycard.png" /></a>
      <a class="more " href="search.php?service=party"><strong>Explore organizers</strong></a>
    </div>
    <div class="carousel-cell" onclick="index.php">
      <h3 class="title">Wedding</h3>
      <a href=""><img class="cardimg" src="images/weddingcard.png" /></a>
      <a class="more " href="search.php?service=wedding"><strong>Explore organizers</strong></a>
    </div>
    <div class="carousel-cell" onclick="index.php">
      <h3 class="title">Corporate</h3>
      <a href=""><img class="cardimg" src="images/corp.png" /></a>
      <a class="more " href="search.php?service=corporate"><strong>Explore organizers</strong></a>
    </div>
    
  </div>
</div>
</div>