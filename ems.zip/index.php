<?php

ob_start();




?>
<?php include 'navbar.php';?>
<!--search-->
<center>
        <div class="container inline" >
        <div class="row">    
        <div class="col-xs-8 col-xs-offset-2">
		    <div class="input-group">
                <div class="input-group-btn search-panel"> 
           
	<form action="search.php" style="display:inline;">
  
         <input type="text"  class="form-control" name="services" placeholder="Search services...">
        <span class="input-group-btn">
        <input class="btn btn-default" type="submit"  value="search">
         </span>
         </div>
        </div>
        </div>
	</div>
</div>
</form>
</center>


<div class="slideshow-container">

<div class="mySlides fade">
  <img src="images/wedding.jpg" style="width:100%">
  <div class="slide-text">Every Event Should be <strong>Perfect</strong>
  <div class="link"><a href="search.php?service=wedding">Book Now!</a></div>
</div>
</div>

<div class="mySlides fade">
  <img src="images/partyback.png" style="width:100%">
  <div class="slide-text">Handpicked event Organizers for your event.
  <div class="link"><a href="search.php?service=parties">Book Now!</a></div>
</div>
</div>

<div class="mySlides fade">
  <img src="images/corpcard.png" style="width:100%">
  <div class="slide-text">Plan your Parties with Eventoz to make your special day even more memorable.
  <div class="link"><a href="search.php?service=corporate">Book Now!</a></div>
  </div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>



<!--card style start-->
<link rel="stylesheet" href="https://unpkg.com/flickity@2.0/dist/flickity.min.css">
<script src="https://unpkg.com/flickity@2.0/dist/flickity.pkgd.min.js"></script>
<!--card style end-->
 






<!--auto slide-->

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 3500); 
}
</script>

<!--slide button-->

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>


 <!--card include-->
<?php include 'homecards.php';?>

<!--service section-->

<section class="service-type">
            <div class="container">
                <div class="heading">
                </div>
                <div class="service-catagari " >
                    <ul>
                        <li>
                            <a href="search.php?services=caterers">
                                <span class="icon size"><img src="images/dish.svg"></span>
                                <span class="text text-color">Caterers</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=decor">
                                <span class="icon size"><img src="images/balloons.svg" alt=""></span>
                                <span class="text text-color">Decor &amp; Florists</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Event Planner">
                                <span class="icon size"><img src="images/appointment.svg" alt=""></span>
                                <span class="text text-color">Event Planner</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Make-up and Hair">
                                <span class="icon size"><img src="images/make-up.svg" alt=""></span>
                                
                                <span class="text text-color">Make-up and Hair</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Make-up and Hair">
                                <span class="icon size"><img src="images/wedding-invitation.svg" alt=""></span>
                                <span class="text text-color">Wedding Cards</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Mehandi">
                                <span class="icon size"><img src="images/tattoo.svg" alt=""></span>
                                
                                <span class="text text-color">Mehandi</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Cakes">
                                <span class="icon size"><img src="images/cake.svg" alt=""></span>
                                
                                <span class="text text-color">Cakes</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=DJ">
                                <span class="icon size"><img src="images/settings.svg" alt=""></span>
                                
                                <span class="text text-color">DJ</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Photographers">
                                <span class="icon size"><img src="images/camera.svg" alt=""></span>
                                
                                <span class="text text-color">Photographers &amp; Videographers</span>
                            </a>
                        </li>
                        <li>
                            <a href="search.php?services=Entertainment">
                                <span class="icon size"><img src="images/microphone-with-wire.svg" alt=""></span>                                
                                <span class="text text-color">Entertainment</span>
                            </a>
                        </li>
                        <li>
                                <a href="search.php?services=Lights & sound">
                                    <span class="icon size"><img src="images/spotlights.svg" alt=""></span>                                
                                    <span class="text text-color">Lights & sound</span>
                                </a>
                            </li>
                         <li>
                                <a href="search.php?services=Valet parking">
                                    <span class="icon size"><img src="images/valet.svg" alt=""></span>                                
                                    <span class="text text-color">Valet parking</span>
                                </a>
                         </li>
                         <li>
                                <a href="search.php?services=Security">
                                    <span class="icon size"><img src="images/policeman.svg" alt=""></span>                                
                                    <span class="text text-color">Security</span>
                                </a>
                        </li>
                        <li>
                                <a href="search.php?services=Gifts">
                                    <span class="icon size"><img src="images/gift.svg" alt=""></span>                                
                                    <span class="text text-color">Gifts</span>
                                </a>
                        </li>
                    </ul>
            
                </div>
            </div>

<?php include 'footer.php';?>

