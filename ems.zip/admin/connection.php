<?php

$hostname="localhost";
$username="root";
$password="";
$dbname="ems";

$conn=mysqli_connect($hostname,$username,$password,$dbname);

if(!$conn){
  die ("Connection error". mysqli_error()); 
}

?>