<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge pink"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
										
									 
									<li id="menu-academico" ><a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span><div class="clearfix"></div></a></li>
									
									<li><a href="manage-vendors.php"><i class="fa fa-list" aria-hidden="true"></i>  <span>Manage Vendors</span><div class="clearfix"></div></a></li>
									 <li><a href="manage-comments.php"><i class="fa fa-file-text-o"></i>  <span>Manage Comments</span><div class="clearfix"></div></a></li>
									
								  </ul>
								</div>
							  </div>